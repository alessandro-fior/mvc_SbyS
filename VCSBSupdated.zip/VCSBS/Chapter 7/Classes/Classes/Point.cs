﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Classes
{
    class Point
    {
        // TODO: Add the constructor and members for the Point class
    }
}
