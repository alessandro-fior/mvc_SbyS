﻿using System;

namespace Classes
{
    class Program
    {
        static void doWork()
        {
            // TODO: Test the Point class
        }

        static void Main(string[] args)
        {
            try
            {
                doWork();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
