﻿using System;

namespace StudentEnrolment
{
    class Program
    {
        static void doWork()
        {
            // TODO:
        }

        static void Main(string[] args)
        {
            try
            {
                doWork();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
