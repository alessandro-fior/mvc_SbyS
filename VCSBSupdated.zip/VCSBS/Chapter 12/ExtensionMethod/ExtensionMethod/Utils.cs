﻿using System;

namespace Extensions
{
    static class Utils
    {
        // TODO:
    }
}