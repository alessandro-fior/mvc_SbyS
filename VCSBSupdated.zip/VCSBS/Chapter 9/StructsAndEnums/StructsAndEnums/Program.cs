﻿using System;

namespace StructsAndEnums
{
    class Program
    {
        static void doWork()
        {
            // TODO: Test the enumeration
        }

        static void Main()
        {
            try
            {
                doWork();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
