﻿using System;

namespace StructsAndEnums
{
    // TODO: Implement Date struct
}
