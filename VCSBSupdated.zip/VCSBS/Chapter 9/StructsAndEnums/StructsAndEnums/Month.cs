﻿using System;

namespace StructsAndEnums
{
    // TODO: Implement Month enumeration
}
